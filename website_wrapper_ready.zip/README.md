# WebsiteWrapper
این پروژه یک اپ ساده اندروید (Kotlin) است که وب‌سایت شما را در WebView لود می‌کند.

این پروژه برای سایت: https://host.one-cloudflare.workers.dev/

ساخت و نصب:
1. Android Studio را باز کنید -> Open -> فولدر `WebsiteWrapper_for_user` را باز کنید.
2. Gradle sync شود، سپس `Build > Build Bundle(s) / APK(s) > Build APK(s)` را انتخاب کنید.
3. خروجی در `app/build/outputs/apk/debug/app-debug.apk` خواهد بود.
